let menu =document.querySelector('#menu-btn');
let navbar =document.querySelector('.navbar');
menu.onclick = () => {
    menu.classList.toggle('fa-times');
    navbar.classList.toggle('active');
}
window.onscroll = () => {
    menu.classList.remove('fa-times');
    navbar.classList.remove('active');
}


function fun() {
    var flightNumber = document.getElementById('flight-number').value;
    var departureTime = document.getElementById('departure-time');
    var arrivalTime = document.getElementById('arrival-time');

    if (flightNumber == "Select") {
        alert("Please select a flight number");
        document.getElementById('flight-number').focus();
    } else {
        
        if (flightNumber == "FL001") {
            departureTime.value = "10:00"; 
            arrivalTime.value = "08:00";   
        } else if (flightNumber == "FL002") {
            departureTime.value = "11:00"; 
            arrivalTime.value = "09:00";   
        } else if (flightNumber == "FL003") {
            departureTime.value = "12:00"; 
            arrivalTime.value = "10:00";   
        }
        
  
        document.forms['timing'].submit();
        alert("Data submitted successfully");
    }
}

function login() {
    var email = document.forms["loginForm"]["email"].value;
    var password = document.forms["loginForm"]["password"].value;

    if (email == "") {
        alert("Email must be filled out");
        return false;
    }

    if (password == "") {
        alert("Password must be filled out");
        return false;
    }
}

function register() {
    var fullname = document.forms["registrationForm"]["fullname"].value;
    var email = document.forms["registrationForm"]["email"].value;
    var password = document.forms["registrationForm"]["password"].value;
    var confirm_password = document.forms["registrationForm"]["confirm_password"].value;

    if (fullname == "") {
        alert("Full Name must be filled out");
        return false;
    }

    if (email == "") {
        alert("Email must be filled out");
        return false;
    }

    if (password == "") {
        alert("Password must be filled out");
        return false;
    }

    if (confirm_password == "") {
        alert("Confirm Password must be filled out");
        return false;
    }

    if (password != confirm_password) {
        alert("Passwords do not match");
        return false;
    }
}

    function add() {
        let passengersContainer = document.getElementById('passenger-details');
        let passengerCount = passengersContainer.querySelectorAll('.passenger').length + 1;

        if (passengerCount <= 10) {
            let newPassengerDiv = document.createElement('div');
            newPassengerDiv.classList.add('passenger');
            newPassengerDiv.innerHTML = `
                <input type="text" placeholder="Passenger ${passengerCount} Name" name="passenger${passengerCount}-name" class="box">
                <input type="number" placeholder="Passenger ${passengerCount} Age" name="passenger${passengerCount}-age" class="box">
                <select placeholder="Passenger ${passengerCount} Gender" name="passenger${passengerCount}-gender" class="box">
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                </select>
            `;

            passengersContainer.appendChild(newPassengerDiv);
        } else {
            alert("Maximum of 10 passengers allowed.");
        }
    }

    function proceedToPayment() {
        if (confirm("Are you sure you want to proceed to payment?")) {
            window.location.href = 'payment.html';
        }
    }

    function adddata() {
        localStorage.setItem("Name", document.getElementById("t1").value);
        localStorage.setItem("Preferences", document.getElementById("t2").value);
        localStorage.setItem("Issues", document.getElementById("t3").value);
        localStorage.setItem("Suggestions", document.getElementById("t4").value);


        
        
        document.write("Your feedback: ");
        document.write("<br>Name: " + localStorage.getItem("Name"));
        document.write("<br>Preferences: " + localStorage.getItem("Preferences"));
        document.write("<br>Issues: " + localStorage.getItem("Issues"));
        document.write("<br>Suggestions: " + localStorage.getItem("Suggestions"));
    }
    









    