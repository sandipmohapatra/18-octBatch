
const questions =[
    {
        question:"What does HTML stands for?",
        answer:[
            { text :"Hypertext Machine language", correct:false},
            { text :"Hypertext and links markup language", correct:false},
            { text :"Hypertext Markup Language", correct:true},
            { text :"Hightext machine language", correct:false},
        ]
    },
    {
        question:"What is the font-size of the h1 heading tag?",
        answer:[
            { text :"2 em", correct:true},
            { text :"2.17 em", correct:false},
            { text :"3.5 em", correct:false},
            { text :"1.5 em", correct:false},
        ]
    },
    {
        question:"what is your name",
        answer:[
            { text :"3", correct:false},
            { text :"2", correct:false},
            { text :"5", correct:false},
            { text :"6", correct:true},
        ]
    },
    {
        question:"How many attributes are there in HTML5?",
        answer:[
            { text :"2", correct:false},
            { text :"4", correct:false},
            { text :"1", correct:false},
            { text :"None of the Above", correct:true},
        ]
    },
    {
        question:"Which of the following attributes is used to add link to any element?",
        answer:[
            { text :"link", correct:false},
            { text :"ref", correct:false},
            { text :"href", correct:true},
            { text :"newref", correct:false},
        ]
    },
    {
        question:"What is the purpose of using div tags in HTML?",
        answer:[
            { text :"For creating Different styles", correct:false},
            { text :"For creating different sections", correct:true},
            { text :"For adding headings", correct:false},
            { text :"For adding titles", correct:false},
        ]
    },
  
    {
        question:"Which of the following attributes is used to open an hyperlink in new tab?",
        answer:[
            { text :"tab", correct:false},
            { text :"href", correct:false},
            { text :"target", correct:true},
            { text :"ref", correct:false},
        ]
    },
    
];

const questionElement = document.getElementById("question");
const answerButtons = document.getElementById("answer-buttons")
const nextButton = document.getElementById("next");

let currentQuestionIndex=0;
let score=0;

function startQuiz(){
    currentQuestionIndex=0;
    score =0;
    nextButton.innerHTML="Next";
    showQuestion();
}
function showQuestion(){
    resetState();
    let currentQuestion = questions[currentQuestionIndex];
    let questionNo = currentQuestionIndex +1;
    questionElement.innerHTML= questionNo+"."+currentQuestion.question;


    currentQuestion.answer.forEach(answer =>{
        const button=document.createElement("button");
        button.innerHTML=answer.text;
        button.classList.add("btn");
        answerButtons.appendChild(button);
        if(answer.correct){
            button.dataset.correct= answer.correct;
        }
        button.addEventListener("click",selectAnswer);
    });
}

function resetState(){
    nextButton.style.display="none";
    while(answerButtons.firstChild){
        answerButtons.removeChild(answerButtons.firstChild)
    }
}

function selectAnswer(e){
    const selectedBtn = e.target;
    const isCorrect= selectedBtn.dataset.correct==="true";
    if(isCorrect){
        selectedBtn.classList.add("correct");
        score++;
    }
    else{
        selectedBtn.classList.add("incorrect");
    }
    Array.from(answerButtons.children).forEach(button =>{
        if(button.dataset.correct==="true"){
            button.classList.add("correct");
        }
        button.disabled = true;
    });
    nextButton.style.display="block";
}
function showScore(){
    resetState();
    questionElement.innerHTML=`you scored ${score}out of ${questions.length}!`;
    nextButton.innerHTML="Re-Test";
    nextButton.style.display="block";
}
function handleNextButton(){
    currentQuestionIndex++;
    if(currentQuestionIndex<questions.length){
        showQuestion();
    }
    else{
        showScore();
    }
}

nextButton.addEventListener("click",()=>{
    if(currentQuestionIndex<questions.length){
        handleNextButton();
    }
    else{
        startQuiz();
    }
})


const start =10;
let time =start *60;
const countdownEl=document.getElementById('countdown');
setInterval(updateCountdown,1000);

function updateCountdown(){
    const minutes=Math.floor(time/60);
    let seconds=time %60;

    seconds = seconds<10?'0'+seconds : seconds;
    countdownEl.innerHTML=`${minutes}:${seconds}`;
    time--;
}